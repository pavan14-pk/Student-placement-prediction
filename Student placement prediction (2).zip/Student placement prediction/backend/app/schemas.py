from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=80)
    email: str = Field(..., min_length=5)
    password: str = Field(..., min_length=6)
    role: str = "student"


class LoginRequest(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    role: str

    model_config = ConfigDict(from_attributes=True)


class PredictionRequest(BaseModel):
    cgpa: float = Field(..., ge=0, le=10)
    tenth_percentage: float = Field(..., ge=0, le=100)
    twelfth_percentage: float = Field(..., ge=0, le=100)
    backlogs: int = Field(..., ge=0, le=20)
    programming_score: float = Field(..., ge=0, le=100)
    dsa_score: float = Field(..., ge=0, le=100)
    communication_score: float = Field(..., ge=0, le=100)
    aptitude_score: float = Field(..., ge=0, le=100)
    projects_completed: int = Field(..., ge=0, le=20)
    internships: int = Field(..., ge=0, le=10)
    certifications: int = Field(..., ge=0, le=20)
    technical_skills: float = Field(..., ge=0, le=100)
    degree: str = Field(..., min_length=2)
    graduation_year: int = Field(..., ge=2020, le=2035)
    work_experience: int = Field(..., ge=0, le=10)

    @field_validator("degree")
    @classmethod
    def valid_degree(cls, value: str) -> str:
        allowed = {"CSE", "IT", "ECE", "EEE", "MECH", "CIVIL", "CS", "Civil", "Computer Science"}
        if value.strip() not in allowed and value.strip().lower() not in {item.lower() for item in allowed}:
            return value.strip()
        return value.strip()


class PredictionResponse(BaseModel):
    label: str
    probability: Optional[float] = None
    status: str
    strengths: list[str]
    improvement_areas: list[str]
    recommendations: list[str]
    message: str


class StudentHistoryItem(BaseModel):
    id: int
    predicted_label: str
    probability: Optional[float]
    summary: Optional[str]
    recommendations: Optional[str]
    created_at: str

    model_config = ConfigDict(from_attributes=True)


class AdminMetrics(BaseModel):
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    roc_auc: Optional[float] = None
    model_name: str = "unknown"
