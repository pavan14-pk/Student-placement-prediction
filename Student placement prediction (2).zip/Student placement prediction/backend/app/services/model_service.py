import json
from pathlib import Path

import joblib
import pandas as pd

from app.services.recommendation_service import build_recommendations

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent
MODEL_PATH = PROJECT_ROOT / "models" / "placement_model.joblib"
METRICS_PATH = PROJECT_ROOT / "models" / "metrics.json"

FEATURE_ORDER = [
    "cgpa",
    "tenth_percentage",
    "twelfth_percentage",
    "backlogs",
    "programming_score",
    "dsa_score",
    "communication_score",
    "aptitude_score",
    "projects_completed",
    "internships",
    "certifications",
    "technical_skills",
    "degree",
    "graduation_year",
    "work_experience",
]


class ModelService:
    def __init__(self, model_path: Path = MODEL_PATH, metrics_path: Path = METRICS_PATH):
        self.model_path = model_path
        self.metrics_path = metrics_path
        self._artifact = None

    @property
    def artifact(self):
        if self._artifact is None:
            if not self.model_path.exists():
                raise FileNotFoundError(f"Model artifact not found at {self.model_path}")
            self._artifact = joblib.load(self.model_path)
        return self._artifact

    def get_metrics(self):
        if self.metrics_path.exists():
            with self.metrics_path.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        return {"model_name": "unknown"}

    @staticmethod
    def _normalize_payload(payload: dict) -> dict:
        normalized = {}
        for key, default in {
            "cgpa": 0.0,
            "tenth_percentage": 0.0,
            "twelfth_percentage": 0.0,
            "backlogs": 0,
            "programming_score": 0.0,
            "dsa_score": 0.0,
            "communication_score": 0.0,
            "aptitude_score": 0.0,
            "projects_completed": 0,
            "internships": 0,
            "certifications": 0,
            "technical_skills": 0.0,
            "degree": "CSE",
            "graduation_year": 2027,
            "work_experience": 0,
        }.items():
            value = payload.get(key, default)
            if isinstance(value, str):
                value = value.strip()
            if key in {"cgpa", "tenth_percentage", "twelfth_percentage", "programming_score", "dsa_score", "communication_score", "aptitude_score", "technical_skills"}:
                try:
                    value = float(value)
                except (TypeError, ValueError):
                    value = float(default)
            elif key in {"backlogs", "projects_completed", "internships", "certifications", "work_experience", "graduation_year"}:
                try:
                    value = int(float(value))
                except (TypeError, ValueError):
                    value = int(default)
            elif key == "degree":
                value = str(value or "CSE").strip() or "CSE"
                value = value.title() if value.lower() not in {"cse", "it", "ece", "eee", "mech", "civil"} else value.upper() if value.lower() == "cse" else value.title()
            normalized[key] = value
        return normalized

    def predict(self, payload: dict):
        artifact = self.artifact
        model = artifact["model"]
        normalized_payload = self._normalize_payload(payload)
        feature_map = {key: normalized_payload.get(key, 0) for key in FEATURE_ORDER}

        record = pd.DataFrame([feature_map], columns=FEATURE_ORDER)
        probability = float(model.predict_proba(record)[0][1])
        label = "Higher predicted placement likelihood" if probability >= 0.5 else "Lower predicted placement likelihood"

        strengths, improvement_areas, recommendations = build_recommendations(normalized_payload, probability)
        return {
            "label": label,
            "probability": round(probability, 4),
            "strengths": strengths,
            "improvement_areas": improvement_areas,
            "recommendations": recommendations,
            "status": "success",
            "message": "Prediction generated using the trained placement model. This is an estimate and not a guarantee of employment.",
        }


model_service = ModelService()
