def build_recommendations(payload: dict, probability: float):
    strengths = []
    improvement_areas = []
    recommendations = []

    if payload.get("cgpa", 0) >= 8.0:
        strengths.append("Strong academic foundation")
    else:
        improvement_areas.append("Academic performance")
        recommendations.append("Focus on maintaining consistency in core subjects and seek tutoring or revision planning for weak units.")

    if payload.get("programming_score", 0) >= 75:
        strengths.append("Programming skills are above the benchmark")
    else:
        improvement_areas.append("Programming proficiency")
        recommendations.append("Practice coding daily on platforms like HackerRank or LeetCode and build at least two practical projects.")

    if payload.get("dsa_score", 0) >= 70:
        strengths.append("Data structures and algorithms are a strength")
    else:
        improvement_areas.append("Data structures and algorithms")
        recommendations.append("Revisit arrays, trees, graphs, and dynamic programming through guided practice and mock interviews.")

    if payload.get("communication_score", 0) >= 70:
        strengths.append("Communication skills are solid")
    else:
        improvement_areas.append("Communication skills")
        recommendations.append("Join speaking groups, practice mock interviews, and improve verbal clarity for technical discussions.")

    if payload.get("aptitude_score", 0) >= 70:
        strengths.append("Aptitude performance is healthy")
    else:
        improvement_areas.append("Aptitude preparedness")
        recommendations.append("Practice quantitative aptitude, logical reasoning, and speed-based tests using a structured weekly plan.")

    if payload.get("projects_completed", 0) < 2:
        improvement_areas.append("Project experience")
        recommendations.append("Complete at least one meaningful project aligned with your target domain and document it clearly.")
    else:
        strengths.append("Project experience supports placement readiness")

    if payload.get("internships", 0) == 0:
        improvement_areas.append("Internship exposure")
        recommendations.append("Apply for internship opportunities, freelancing work, and summer training experiences relevant to your field.")
    else:
        strengths.append("Internship experience adds practical value")

    if payload.get("certifications", 0) == 0:
        improvement_areas.append("Professional certification")
        recommendations.append("Earn one or two domain-specific certifications to strengthen your profile and show initiative.")
    else:
        strengths.append("Certification profile is encouraging")

    if probability >= 0.7:
        recommendations.insert(0, "Your current profile is strong. Continue building depth in your key skills and keep preparing for interviews.")
    elif probability >= 0.5:
        recommendations.insert(0, "Your profile is moderately competitive. Focus on a few critical areas to improve your placement odds.")
    else:
        recommendations.insert(0, "Your profile is currently below the typical placement benchmark. Use the recommendations below to target the most important improvements.")

    return strengths, improvement_areas, recommendations
