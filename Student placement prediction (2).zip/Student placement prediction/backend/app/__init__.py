"""Student Placement Prediction backend package."""
