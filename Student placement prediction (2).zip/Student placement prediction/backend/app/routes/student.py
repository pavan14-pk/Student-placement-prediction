from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.models import PredictionHistory, StudentProfile, User
from app.schemas import PredictionRequest, PredictionResponse
from app.services.model_service import model_service

router = APIRouter()


@router.get("/profile")
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if profile is None:
        return {"profile": None}
    return {
        "profile": {
            "cgpa": profile.cgpa,
            "tenth_percentage": profile.tenth_percentage,
            "twelfth_percentage": profile.twelfth_percentage,
            "backlogs": profile.backlogs,
            "programming_score": profile.programming_score,
            "dsa_score": profile.dsa_score,
            "communication_score": profile.communication_score,
            "aptitude_score": profile.aptitude_score,
            "projects_completed": profile.projects_completed,
            "internships": profile.internships,
            "certifications": profile.certifications,
            "technical_skills": profile.technical_skills,
            "degree": profile.degree,
            "graduation_year": profile.graduation_year,
            "work_experience": profile.work_experience,
        }
    }


@router.get("/history")
def get_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = (
        db.query(PredictionHistory)
        .filter(PredictionHistory.user_id == current_user.id)
        .order_by(PredictionHistory.created_at.desc())
        .all()
    )

    return {
        "history": [
            {
                "id": item.id,
                "predicted_label": item.predicted_label,
                "probability": item.probability,
                "summary": item.summary,
                "recommendations": item.recommendations,
                "created_at": item.created_at.isoformat(),
            }
            for item in data
        ]
    }


@router.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    try:
        prediction = model_service.predict(payload.model_dump())
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail="Model artifact is unavailable. Please train the model first.") from exc

    payload_data = payload.model_dump()
    profile = db.query(StudentProfile).filter(StudentProfile.user_id == current_user.id).first()
    if profile is None:
        profile = StudentProfile(user_id=current_user.id, **payload_data)
        db.add(profile)
    else:
        for key, value in payload_data.items():
            setattr(profile, key, value)
        profile.updated_at = datetime.utcnow()

    history = PredictionHistory(
        user_id=current_user.id,
        predicted_label=prediction["label"],
        probability=prediction["probability"],
        summary=prediction["message"],
        recommendations="; ".join(prediction["recommendations"]),
    )
    db.add(history)
    db.commit()

    return PredictionResponse(
        label=prediction["label"],
        probability=prediction["probability"],
        status=prediction["status"],
        strengths=prediction["strengths"],
        improvement_areas=prediction["improvement_areas"],
        recommendations=prediction["recommendations"],
        message=prediction["message"],
    )
