from pathlib import Path
import json
import subprocess

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.auth import require_admin
from app.database import get_db
from app.models import PredictionHistory, User
from app.services.model_service import model_service

router = APIRouter()
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent


@router.get("/stats")
def get_admin_stats(current_user: User = Depends(require_admin), db: Session = Depends(get_db)):
    total_students = db.query(User).filter(User.role == "student").count()
    total_predictions = db.query(PredictionHistory).count()
    avg_student_count = total_students or 1
    return {
        "total_students": total_students,
        "total_predictions": total_predictions,
        "student_to_prediction_ratio": round(total_predictions / avg_student_count, 2),
        "latest_model": model_service.get_metrics().get("model_name", "unknown"),
    }


@router.get("/model-metrics")
def get_model_metrics(current_user: User = Depends(require_admin)):
    return model_service.get_metrics()


@router.post("/retrain")
def retrain_model(current_user: User = Depends(require_admin)):
    subprocess.run(["python", str(PROJECT_ROOT / "ml" / "train_model.py")], cwd=str(PROJECT_ROOT), check=True)
    return {
        "message": "Model retraining completed successfully",
        "metrics": model_service.get_metrics(),
    }
