from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app.models import *  # noqa: F401,F403
from app.routes.admin import router as admin_router
from app.routes.auth import router as auth_router
from app.routes.student import router as student_router

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/api/auth")
app.include_router(student_router, prefix="/api/student")
app.include_router(admin_router, prefix="/api/admin")


@app.get("/api/health")
def health_check():
    return {
        "status": "ok",
        "service": "student-placement-prediction",
        "environment": "development",
    }
