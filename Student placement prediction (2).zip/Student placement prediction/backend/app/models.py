from datetime import datetime

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(30), default="student")
    created_at = Column(DateTime, default=datetime.utcnow)

    student_profile = relationship("StudentProfile", back_populates="user", uselist=False)
    predictions = relationship("PredictionHistory", back_populates="user")


class StudentProfile(Base):
    __tablename__ = "student_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    cgpa = Column(Float, nullable=False)
    tenth_percentage = Column(Float, nullable=False)
    twelfth_percentage = Column(Float, nullable=False)
    backlogs = Column(Integer, default=0)
    programming_score = Column(Float, nullable=False)
    dsa_score = Column(Float, nullable=False)
    communication_score = Column(Float, nullable=False)
    aptitude_score = Column(Float, nullable=False)
    projects_completed = Column(Integer, default=0)
    internships = Column(Integer, default=0)
    certifications = Column(Integer, default=0)
    technical_skills = Column(Float, nullable=False)
    degree = Column(String(80), nullable=False)
    graduation_year = Column(Integer, nullable=False)
    work_experience = Column(Integer, default=0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="student_profile")


class PredictionHistory(Base):
    __tablename__ = "prediction_history"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    predicted_label = Column(String(40), nullable=False)
    probability = Column(Float, nullable=True)
    summary = Column(Text, nullable=True)
    recommendations = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="predictions")


class ModelRecord(Base):
    __tablename__ = "model_records"

    id = Column(Integer, primary_key=True, index=True)
    version = Column(String(50), nullable=False)
    model_name = Column(String(80), nullable=False)
    accuracy = Column(Float, nullable=True)
    precision = Column(Float, nullable=True)
    recall = Column(Float, nullable=True)
    f1_score = Column(Float, nullable=True)
    roc_auc = Column(Float, nullable=True)
    saved_at = Column(DateTime, default=datetime.utcnow)


class TrainingDataset(Base):
    __tablename__ = "training_datasets"

    id = Column(Integer, primary_key=True, index=True)
    source = Column(String(120), nullable=False)
    rows_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    description = Column(Text, default="")
