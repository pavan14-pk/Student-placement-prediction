import os
import sys

from fastapi.testclient import TestClient

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.main import app

client = TestClient(app)


def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_register_and_login():
    username = "studentuser123"
    email = "studentuser123@example.com"

    register_response = client.post(
        "/api/auth/register",
        json={"username": username, "email": email, "password": "password123"},
    )
    assert register_response.status_code == 201

    login_response = client.post(
        "/api/auth/login",
        json={"username": username, "password": "password123"},
    )
    assert login_response.status_code == 200
    assert "access_token" in login_response.json()


def test_predict_endpoint_success():
    username = "studentpredictor"
    email = "studentpredictor@example.com"
    client.post(
        "/api/auth/register",
        json={"username": username, "email": email, "password": "password123"},
    )
    login_response = client.post(
        "/api/auth/login",
        json={"username": username, "password": "password123"},
    )
    token = login_response.json()["access_token"]

    payload = {
        "cgpa": 8.7,
        "tenth_percentage": 89,
        "twelfth_percentage": 91,
        "backlogs": 0,
        "programming_score": 86,
        "dsa_score": 82,
        "communication_score": 78,
        "aptitude_score": 81,
        "projects_completed": 3,
        "internships": 1,
        "certifications": 2,
        "technical_skills": 88,
        "degree": "CSE",
        "graduation_year": 2027,
        "work_experience": 0,
    }

    response = client.post(
        "/api/student/predict",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    body = response.json()
    assert "label" in body
    assert "probability" in body
    assert len(body["recommendations"]) > 0


def test_predict_endpoint_rejects_invalid_input():
    username = "studentinvalid"
    email = "studentinvalid@example.com"
    client.post(
        "/api/auth/register",
        json={"username": username, "email": email, "password": "password123"},
    )
    login_response = client.post(
        "/api/auth/login",
        json={"username": username, "password": "password123"},
    )
    token = login_response.json()["access_token"]

    response = client.post(
        "/api/student/predict",
        json={"cgpa": 11, "degree": "CSE"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 422
