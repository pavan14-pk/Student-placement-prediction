# Student Placement Prediction System Using Machine Learning

This project is a full-stack student placement prediction web application built with React + Tailwind CSS on the frontend and FastAPI on the backend. It includes a machine learning pipeline that trains and evaluates models, saves the pipeline and model artifacts, and serves predictions through a REST API.

## Architecture

- Frontend: React + Vite + Tailwind CSS
- Backend: FastAPI + SQLAlchemy + SQLite
- Machine learning: scikit-learn, pandas, numpy, joblib
- Authentication: JWT with secure password hashing
- Model persistence: joblib artifact bundle saved in `models/`
- Database: SQLite with user, profile, prediction history, and admin metadata tables

## Dataset and model approach

The project uses a synthetic student placement dataset generated in the `data/` folder for local development and demonstration. The training script in `ml/train_model.py` compares three classifiers:

1. Logistic Regression
2. Random Forest Classifier
3. Gradient Boosting Classifier

It uses a stratified train/test split, calculates classification metrics, and selects the best model based on validation performance, with ROC-AUC and F1-score used for decision-making.

## Folder structure

```text
student-placement-prediction/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── main.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   ├── routes/
│   │   │   ├── admin.py
│   │   │   ├── auth.py
│   │   │   └── student.py
│   │   └── services/
│   │       ├── model_service.py
│   │       └── recommendation_service.py
│   ├── tests/
│   │   └── test_api.py
│   ├── requirements.txt
│   └── run.py
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── postcss.config.js
│   ├── tailwind.config.js
│   ├── vite.config.js
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       ├── index.css
│       ├── main.jsx
│       ├── components/
│       └── pages/
├── ml/
│   ├── generate_dataset.py
│   └── train_model.py
├── data/
│   └── student_placement_data.csv
├── models/
│   └── placement_model.joblib
├── docs/
│   └── architecture.md
├── .env.example
├── student_placement.db
├── README.md
└── requirements.txt
```

## Quick start

### 1) Create a Python virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2) Install backend dependencies

```bash
pip install -r backend/requirements.txt
```

### 3) Train the model and generate data

```bash
python ml/generate_dataset.py
python ml/train_model.py
```

### 4) Start the backend server

```bash
cd backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 5) Install frontend dependencies

```bash
cd frontend
npm install
```

### 6) Start the frontend

```bash
npm run dev
```

### 7) Run tests

```bash
pytest backend/tests/test_api.py -q
```

## Environment variables

Copy `.env.example` to `.env` and update the values before running the project in a production environment.

## Deployment notes

- Frontend can be deployed to Vercel.
- FastAPI backend can be deployed on Render, Railway, or a similar platform.
- Use a production Postgres database and set `DATABASE_URL` accordingly.
- Configure CORS for the deployed frontend origin in the backend.

## Notes

This application is designed as a reliable academic project and can be extended for a real production environment. Predictions are estimates and should be used as guidance rather than a guarantee of employment.
