import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { studentApi } from '../api';

export default function DashboardPage({ user }) {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const response = await studentApi.history();
        setHistory(response.history || []);
      } catch (error) {
        console.error(error);
      }
    };
    load();
  }, [user]);

  const summary = [
    { label: 'Assessments', value: history.length, tone: 'bg-brand-50 text-brand-700' },
    { label: 'High Likelihood', value: history.filter((item) => item.predicted_label.includes('Higher')).length, tone: 'bg-emerald-50 text-emerald-700' },
    { label: 'Low Likelihood', value: history.filter((item) => item.predicted_label.includes('Lower')).length, tone: 'bg-amber-50 text-amber-700' },
  ];

  const chartData = history.slice(0, 6).reverse().map((item) => ({
    name: new Date(item.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    probability: Number(item.probability || 0) * 100,
  }));

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-slate-800">Student Dashboard</h2>
        <p className="mt-1 text-slate-600">Welcome back, {user.username}. Track your latest assessment outcomes and preparation priorities.</p>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        {summary.map((stat) => (
          <div key={stat.label} className="card p-5">
            <div className={`inline-flex rounded-xl px-3 py-2 text-xs font-semibold ${stat.tone}`}>{stat.label}</div>
            <p className="mt-4 text-3xl font-bold text-slate-800">{stat.value}</p>
          </div>
        ))}
      </section>

      <section className="card p-6">
        <h3 className="text-lg font-semibold text-slate-800">Recent placement probability</h3>
        <div className="mt-6 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={(value) => `${value}%`} domain={[0, 100]} />
              <Tooltip formatter={(value) => [`${value}%`, 'Placement Probability']} />
              <Bar dataKey="probability" fill="#3b82f6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="card p-6">
        <h3 className="text-lg font-semibold text-slate-800">Prediction history</h3>
        <div className="mt-4 space-y-3">
          {history.length === 0 ? (
            <p className="text-slate-500">No predictions yet. Visit the prediction form to start your first assessment.</p>
          ) : (
            history.map((item) => (
              <div key={item.id} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                <div className="flex flex-col justify-between gap-2 sm:flex-row">
                  <div>
                    <p className="font-semibold text-slate-800">{item.predicted_label}</p>
                    <p className="text-sm text-slate-500">{new Date(item.created_at).toLocaleString()}</p>
                  </div>
                  <div className="rounded-lg bg-white px-3 py-2 text-sm font-medium text-brand-600">
                    {Number(item.probability || 0) * 100}% estimated probability
                  </div>
                </div>
                {item.recommendations && <p className="mt-3 text-sm text-slate-600">{item.recommendations}</p>}
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}
