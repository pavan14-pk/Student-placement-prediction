import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { adminApi } from '../api';

export default function AdminPage() {
  const [stats, setStats] = useState({});
  const [metrics, setMetrics] = useState({});

  useEffect(() => {
    const load = async () => {
      try {
        const statsResponse = await adminApi.stats();
        const metricsResponse = await adminApi.metrics();
        setStats(statsResponse);
        setMetrics(metricsResponse);
      } catch (error) {
        console.error(error);
      }
    };
    load();
  }, []);

  const chartData = [
    { name: 'Accuracy', value: Number(metrics.accuracy || 0) * 100 },
    { name: 'Precision', value: Number(metrics.precision || 0) * 100 },
    { name: 'Recall', value: Number(metrics.recall || 0) * 100 },
    { name: 'F1', value: Number(metrics.f1_score || 0) * 100 },
  ];

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-slate-800">Admin analytics</h2>
        <p className="mt-1 text-slate-600">Monitor aggregated student assessments and model evaluation.</p>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <div className="card p-5">
          <p className="text-sm text-slate-500">Students</p>
          <p className="mt-2 text-3xl font-bold">{stats.total_students ?? 0}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-slate-500">Predictions</p>
          <p className="mt-2 text-3xl font-bold">{stats.total_predictions ?? 0}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-slate-500">Selected model</p>
          <p className="mt-2 text-xl font-bold">{metrics.model_name ?? 'unknown'}</p>
        </div>
      </section>

      <section className="card p-6">
        <h3 className="text-lg font-semibold text-slate-800">Model performance</h3>
        <div className="mt-6 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis tickFormatter={(value) => `${value}%`} domain={[0, 100]} />
              <Tooltip formatter={(value) => [`${value}%`, 'Score']} />
              <Bar dataKey="value" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="card p-6">
        <h3 className="text-lg font-semibold text-slate-800">Evaluation summary</h3>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {Object.entries(metrics).map(([key, value]) => (
            <div key={key} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <p className="text-sm text-slate-500">{key.replace('_', ' ')}</p>
              <p className="mt-1 text-lg font-semibold text-slate-800">{typeof value === 'number' ? value.toFixed(3) : value ?? '—'}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
