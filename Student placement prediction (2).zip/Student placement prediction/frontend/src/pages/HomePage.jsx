import { Link } from 'react-router-dom';

const features = [
  {
    title: 'Smart placement prediction',
    text: 'Uses student academic and technical data to estimate placement chances with confidence-based scoring.',
  },
  {
    title: 'Skill gap analysis',
    text: 'Identifies where the student is strong and which areas need improvement before recruitment drives.',
  },
  {
    title: 'Actionable recommendations',
    text: 'Shows career-ready guidance on coding, communication, projects, and interview preparation.',
  },
  {
    title: 'Secure student dashboard',
    text: 'Stores each prediction and profile in a structured system for tracking progress over time.',
  },
];

const stats = [
  { label: 'Placement readiness', value: '82%' },
  { label: 'ML confidence', value: '97%' },
  { label: 'Skill categories', value: '12+' },
];

const steps = [
  'Create your profile and complete the student assessment form.',
  'The model reviews academic, technical, and communication indicators.',
  'Review your prediction, strengths, and next-step recommendations.',
];

export default function HomePage() {
  return (
    <div className="space-y-10">
      <section className="overflow-hidden rounded-[28px] bg-gradient-to-br from-slate-900 via-brand-700 to-violet-700 p-8 text-white shadow-2xl md:p-12">
        <div className="grid items-center gap-8 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <p className="mb-4 text-sm font-semibold uppercase tracking-[0.22em] text-blue-100">Student success platform</p>
            <h2 className="max-w-xl text-4xl font-black leading-tight md:text-5xl">
              Predict placement outcomes with confidence and clarity.
            </h2>
            <p className="mt-4 max-w-xl text-base text-blue-100 md:text-lg">
              Help students understand their readiness for campus placements using academic performance, technical skills, communication, and project experience.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/predict" className="rounded-xl bg-white px-5 py-3 text-sm font-semibold text-brand-700 shadow-lg transition hover:-translate-y-0.5 hover:bg-slate-100">
                Predict My Placement
              </Link>
              <Link to="/auth" className="rounded-xl border border-white/30 bg-white/10 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/15">
                Student Login
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/10 p-5 backdrop-blur-sm">
            <div className="rounded-2xl bg-slate-950/20 p-5">
              <p className="text-xs uppercase tracking-[0.2em] text-blue-100">Placement insight</p>
              <div className="mt-5 space-y-4">
                {stats.map((item) => (
                  <div key={item.label} className="rounded-xl bg-white/10 p-4">
                    <p className="text-xs uppercase tracking-[0.18em] text-blue-100">{item.label}</p>
                    <p className="mt-2 text-3xl font-bold">{item.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {features.map((feature) => (
          <div key={feature.title} className="card p-5 transition hover:-translate-y-1 hover:shadow-lg">
            <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-lg font-bold text-brand-600">
              ✓
            </div>
            <h3 className="text-lg font-bold text-slate-800">{feature.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-600">{feature.text}</p>
          </div>
        ))}
      </section>

      <section className="card p-8">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-brand-600">How it works</p>
            <h3 className="mt-2 text-2xl font-bold text-slate-800">A simple 3-step placement assessment</h3>
          </div>
        </div>

        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {steps.map((step, index) => (
            <div key={step} className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full bg-brand-600 font-bold text-white">
                {index + 1}
              </div>
              <p className="text-slate-700">{step}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
