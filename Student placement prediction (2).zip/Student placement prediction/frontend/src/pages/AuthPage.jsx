import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../api';

export default function AuthPage({ setUser, setToken, user }) {
  const navigate = useNavigate();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = mode === 'login'
        ? await authApi.login({ username: form.username, password: form.password })
        : await authApi.register({ username: form.username, email: form.email, password: form.password });

      if (mode === 'login') {
        setUser(response.user);
        setToken(response.access_token);
        navigate('/dashboard');
      } else {
        setMode('login');
        setForm((prev) => ({ ...prev, email: '' }));
        setError('Registration successful. Please log in now.');
      }
    } catch (err) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-lg">
      <div className="card p-8">
        <div className="mb-6 flex gap-2 rounded-xl bg-slate-100 p-1">
          {['login', 'register'].map((value) => (
            <button
              key={value}
              type="button"
              onClick={() => setMode(value)}
              className={`flex-1 rounded-xl px-3 py-2 text-sm font-medium ${mode === value ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-600'}`}
            >
              {value === 'login' ? 'Login' : 'Register'}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Username</label>
            <input name="username" className="input" value={form.username} onChange={handleChange} required />
          </div>

          {mode === 'register' && (
            <div>
              <label className="label">Email</label>
              <input type="email" name="email" className="input" value={form.email} onChange={handleChange} required />
            </div>
          )}

          <div>
            <label className="label">Password</label>
            <input type="password" name="password" className="input" value={form.password} onChange={handleChange} required minLength={6} />
          </div>

          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Please wait...' : mode === 'login' ? 'Login' : 'Create account'}
          </button>
        </form>
      </div>
    </div>
  );
}
