import { useState } from 'react';
import { studentApi } from '../api';

const defaultForm = {
  cgpa: 8.2,
  tenth_percentage: 88,
  twelfth_percentage: 90,
  backlogs: 0,
  programming_score: 82,
  dsa_score: 80,
  communication_score: 76,
  aptitude_score: 79,
  projects_completed: 2,
  internships: 1,
  certifications: 2,
  technical_skills: 84,
  degree: 'CSE',
  graduation_year: 2027,
  work_experience: 0,
};

const sampleStrongStudent = {
  cgpa: 8.8,
  tenth_percentage: 92,
  twelfth_percentage: 94,
  backlogs: 0,
  programming_score: 90,
  dsa_score: 88,
  communication_score: 82,
  aptitude_score: 85,
  projects_completed: 4,
  internships: 2,
  certifications: 3,
  technical_skills: 91,
  degree: 'CSE',
  graduation_year: 2027,
  work_experience: 0,
};

const numberFields = new Set([
  'cgpa',
  'tenth_percentage',
  'twelfth_percentage',
  'backlogs',
  'programming_score',
  'dsa_score',
  'communication_score',
  'aptitude_score',
  'projects_completed',
  'internships',
  'certifications',
  'technical_skills',
  'graduation_year',
  'work_experience',
]);

const normalizePayload = (payload) => {
  const normalized = { ...payload };

  Object.keys(normalized).forEach((key) => {
    const value = normalized[key];
    if (numberFields.has(key)) {
      normalized[key] = Number(value ?? 0);
    }
  });

  return {
    ...normalized,
    degree: String(normalized.degree || 'CSE').trim() || 'CSE',
  };
};

export default function PredictPage({ user }) {
  const [form, setForm] = useState(defaultForm);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({
      ...prev,
      [name]: numberFields.has(name) ? Number(value) : value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');

    try {
      const payload = normalizePayload(form);
      const response = await studentApi.predict(payload);
      setResult(response);
    } catch (err) {
      setError(err.message || 'Prediction failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
      <div className="card p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Placement assessment form</h2>
            <p className="mt-1 text-slate-600">Fill in your academic and skills data to generate a placement estimate.</p>
          </div>
          <button
            type="button"
            className="btn-muted"
            onClick={() => setForm(sampleStrongStudent)}
          >
            Load sample student
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="label">CGPA</label>
              <input name="cgpa" type="number" min="0" max="10" step="0.1" className="input" value={form.cgpa} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">10th percentage</label>
              <input name="tenth_percentage" type="number" min="0" max="100" className="input" value={form.tenth_percentage} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">12th percentage</label>
              <input name="twelfth_percentage" type="number" min="0" max="100" className="input" value={form.twelfth_percentage} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Backlogs</label>
              <input name="backlogs" type="number" min="0" max="20" className="input" value={form.backlogs} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Programming score</label>
              <input name="programming_score" type="number" min="0" max="100" className="input" value={form.programming_score} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">DSA score</label>
              <input name="dsa_score" type="number" min="0" max="100" className="input" value={form.dsa_score} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Communication skills</label>
              <input name="communication_score" type="number" min="0" max="100" className="input" value={form.communication_score} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Aptitude score</label>
              <input name="aptitude_score" type="number" min="0" max="100" className="input" value={form.aptitude_score} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Projects completed</label>
              <input name="projects_completed" type="number" min="0" max="20" className="input" value={form.projects_completed} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Internships</label>
              <input name="internships" type="number" min="0" max="10" className="input" value={form.internships} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Certifications</label>
              <input name="certifications" type="number" min="0" max="20" className="input" value={form.certifications} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Technical skills</label>
              <input name="technical_skills" type="number" min="0" max="100" className="input" value={form.technical_skills} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Degree</label>
              <select name="degree" className="input" value={form.degree} onChange={handleChange} required>
                <option value="CSE">CSE</option>
                <option value="IT">IT</option>
                <option value="ECE">ECE</option>
                <option value="EEE">EEE</option>
                <option value="MECH">MECH</option>
                <option value="CIVIL">CIVIL</option>
              </select>
            </div>
            <div>
              <label className="label">Graduation year</label>
              <input name="graduation_year" type="number" min="2020" max="2035" className="input" value={form.graduation_year} onChange={handleChange} required />
            </div>
            <div>
              <label className="label">Work experience</label>
              <input name="work_experience" type="number" min="0" max="10" className="input" value={form.work_experience} onChange={handleChange} required />
            </div>
          </div>

          {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Generating prediction...' : 'Generate prediction'}
          </button>
        </form>
      </div>

      <div className="card p-6">
        <h3 className="text-xl font-bold text-slate-800">Prediction outcome</h3>
        {!result ? (
          <div className="mt-6 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-6 text-sm text-slate-500">
            Fill in the form to view your predicted placement likelihood, strengths, and preparation guidance.
          </div>
        ) : (
          <div className="mt-6 space-y-5">
            <div className="rounded-2xl bg-gradient-to-r from-brand-50 to-violet-50 p-4">
              <p className="text-sm font-medium text-slate-500">Result</p>
              <p className="mt-1 text-xl font-bold text-slate-800">{result.label}</p>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <span className="text-sm font-medium text-slate-600">Estimated probability</span>
                <span className="text-sm font-semibold text-brand-600">{Math.round((Number(result.probability || 0) * 100))}%</span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-slate-200">
                <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-violet-500" style={{ width: `${Math.max(8, Number(result.probability || 0) * 100)}%` }} />
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800">Strengths</h4>
              <ul className="mt-2 list-disc pl-5 text-sm text-slate-600">
                {result.strengths.map((item) => <li key={item}>{item}</li>)}
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800">Improvement areas</h4>
              <ul className="mt-2 list-disc pl-5 text-sm text-slate-600">
                {result.improvement_areas.map((item) => <li key={item}>{item}</li>)}
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-800">Recommendations</h4>
              <ul className="mt-2 list-disc pl-5 text-sm text-slate-600">
                {result.recommendations.map((item) => <li key={item}>{item}</li>)}
              </ul>
            </div>

            <p className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-700">
              {result.message}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
