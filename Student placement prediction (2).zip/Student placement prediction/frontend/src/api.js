const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('placement_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();

  if (!response.ok) {
    const errorMessage = typeof data === 'string' ? data : data.detail || 'Request failed';
    throw new Error(errorMessage);
  }

  return data;
}

export const authApi = {
  register: (payload) => apiFetch('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) }),
  login: (payload) => apiFetch('/api/auth/login', { method: 'POST', body: JSON.stringify(payload) }),
};

export const studentApi = {
  predict: (payload) => apiFetch('/api/student/predict', { method: 'POST', body: JSON.stringify(payload) }),
  history: () => apiFetch('/api/student/history'),
  profile: () => apiFetch('/api/student/profile'),
};

export const adminApi = {
  stats: () => apiFetch('/api/admin/stats'),
  metrics: () => apiFetch('/api/admin/model-metrics'),
  retrain: () => apiFetch('/api/admin/retrain', { method: 'POST' }),
};

export const healthApi = {
  check: () => apiFetch('/api/health'),
};
