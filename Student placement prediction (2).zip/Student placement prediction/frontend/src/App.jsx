import { useEffect, useState } from 'react';
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import AdminPage from './pages/AdminPage';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import HomePage from './pages/HomePage';
import PredictPage from './pages/PredictPage';

function App() {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('placement_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem('placement_token') || '');

  useEffect(() => {
    if (user) {
      localStorage.setItem('placement_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('placement_user');
    }
  }, [user]);

  useEffect(() => {
    if (token) {
      localStorage.setItem('placement_token', token);
    } else {
      localStorage.removeItem('placement_token');
    }
  }, [token]);

  const logout = () => {
    setUser(null);
    setToken('');
  };

  const isAdmin = user?.role === 'admin';

  const navItems = [
    { to: '/', label: 'Home' },
    { to: '/predict', label: 'Predict' },
    { to: '/dashboard', label: 'Dashboard' },
    ...(isAdmin ? [{ to: '/admin', label: 'Admin' }] : []),
  ];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-brand-600">AI Placement Predictor</p>
            <h1 className="text-xl font-bold">Student Placement Prediction System</h1>
          </div>

          <nav className="hidden items-center gap-6 md:flex">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `text-sm font-medium ${isActive ? 'text-brand-600' : 'text-slate-600 hover:text-slate-900'}`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <span className="hidden text-sm font-medium text-slate-600 sm:inline">{user.username}</span>
                <button className="btn-muted" onClick={logout}>Logout</button>
              </>
            ) : (
              <NavLink to="/auth" className="btn-primary">Login / Register</NavLink>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth" element={<AuthPage setUser={setUser} setToken={setToken} user={user} />} />
          <Route path="/predict" element={user ? <PredictPage user={user} /> : <AuthPage setUser={setUser} setToken={setToken} user={user} />} />
          <Route path="/dashboard" element={user ? <DashboardPage user={user} /> : <AuthPage setUser={setUser} setToken={setToken} user={user} />} />
          <Route path="/admin" element={user && isAdmin ? <AdminPage user={user} /> : <AuthPage setUser={setUser} setToken={setToken} user={user} />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
