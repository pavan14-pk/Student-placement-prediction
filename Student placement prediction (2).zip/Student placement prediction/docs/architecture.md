# Project architecture

This application is designed in three layers:

1. Frontend layer
   - React + Vite + Tailwind provides a modern student-facing dashboard and prediction workflow.

2. Backend layer
   - FastAPI exposes `/api/auth/*`, `/api/student/*`, `/api/admin/*`, and `/api/health`.
   - SQLAlchemy models persist users, profiles, prediction history, and training metadata in SQLite.

3. ML layer
   - A Python training pipeline prepares a synthetic student dataset, compares models, selects the strongest classifier, and saves the final pipeline.

The key design principle is that the same feature order and preprocessing steps used during training are also used at prediction time, ensuring the model behaves consistently and safely.
