from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "student_placement_data.csv"


def generate_student_dataset(rows: int = 900) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    degrees = ["CSE", "IT", "ECE", "EEE", "MECH", "CIVIL"]

    records = []
    for i in range(rows):
        degree = rng.choice(degrees)
        placement_status = 1 if i % 2 == 0 else 0

        if placement_status == 1:
            cgpa = float(rng.uniform(7.2, 9.8))
            tenth_percentage = float(rng.uniform(75, 98))
            twelfth_percentage = float(rng.uniform(78, 99))
            backlogs = int(rng.integers(0, 2))
            programming_score = float(rng.uniform(70, 98))
            dsa_score = float(rng.uniform(68, 97))
            communication_score = float(rng.uniform(65, 95))
            aptitude_score = float(rng.uniform(70, 98))
            projects_completed = int(rng.integers(2, 6))
            internships = int(rng.integers(0, 3))
            certifications = int(rng.integers(1, 5))
            technical_skills = float(rng.uniform(70, 99))
        else:
            cgpa = float(rng.uniform(4.5, 7.4))
            tenth_percentage = float(rng.uniform(50, 85))
            twelfth_percentage = float(rng.uniform(52, 87))
            backlogs = int(rng.integers(0, 4))
            programming_score = float(rng.uniform(35, 70))
            dsa_score = float(rng.uniform(30, 68))
            communication_score = float(rng.uniform(40, 72))
            aptitude_score = float(rng.uniform(35, 70))
            projects_completed = int(rng.integers(0, 3))
            internships = int(rng.integers(0, 2))
            certifications = int(rng.integers(0, 3))
            technical_skills = float(rng.uniform(35, 72))

        graduation_year = int(rng.integers(2024, 2028))
        work_experience = int(rng.integers(0, 2))

        degree_bonus = {"CSE": 0.9, "IT": 0.7, "ECE": 0.6, "EEE": 0.5, "MECH": 0.45, "CIVIL": 0.35}[degree]
        score = (
            0.24 * cgpa
            + 0.12 * (tenth_percentage / 10)
            + 0.12 * (twelfth_percentage / 10)
            + 0.10 * (programming_score / 10)
            + 0.12 * (dsa_score / 10)
            + 0.08 * (communication_score / 10)
            + 0.08 * (aptitude_score / 10)
            + 0.08 * (technical_skills / 10)
            + 0.06 * degree_bonus
            + 0.05 * min(projects_completed, 5)
            + 0.04 * min(internships, 2)
            + 0.03 * min(certifications, 3)
            - 0.08 * backlogs
            - 0.04 * work_experience
        )

        placement_status = 1 if score >= 5.7 else 0

        records.append(
            {
                "cgpa": round(cgpa, 2),
                "tenth_percentage": round(tenth_percentage, 2),
                "twelfth_percentage": round(twelfth_percentage, 2),
                "backlogs": backlogs,
                "programming_score": round(programming_score, 2),
                "dsa_score": round(dsa_score, 2),
                "communication_score": round(communication_score, 2),
                "aptitude_score": round(aptitude_score, 2),
                "projects_completed": projects_completed,
                "internships": internships,
                "certifications": certifications,
                "technical_skills": round(technical_skills, 2),
                "degree": degree,
                "graduation_year": graduation_year,
                "work_experience": work_experience,
                "placement_status": placement_status,
            }
        )

    df = pd.DataFrame(records)
    return df


if __name__ == "__main__":
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    dataset = generate_student_dataset()
    dataset.to_csv(DATA_PATH, index=False)
    print(f"Generated dataset with {len(dataset)} rows at {DATA_PATH}")
