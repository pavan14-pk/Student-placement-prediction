import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "student_placement_data.csv"
MODEL_PATH = PROJECT_ROOT / "models" / "placement_model.joblib"
METRICS_PATH = PROJECT_ROOT / "models" / "metrics.json"

FEATURE_COLUMNS = [
    "cgpa",
    "tenth_percentage",
    "twelfth_percentage",
    "backlogs",
    "programming_score",
    "dsa_score",
    "communication_score",
    "aptitude_score",
    "projects_completed",
    "internships",
    "certifications",
    "technical_skills",
    "degree",
    "graduation_year",
    "work_experience",
]
TARGET_COLUMN = "placement_status"


def compute_metrics(y_true, y_pred, y_proba=None):
    metrics = {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
        "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_true, y_pred, zero_division=0)), 4),
    }
    if y_proba is not None and len(set(y_true)) > 1:
        metrics["roc_auc"] = round(float(roc_auc_score(y_true, y_proba)), 4)
    metrics["confusion_matrix"] = confusion_matrix(y_true, y_pred).tolist()
    return metrics


if __name__ == "__main__":
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found at {DATA_PATH}. Run ml/generate_dataset.py first.")

    df = pd.read_csv(DATA_PATH)
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Expected target column '{TARGET_COLUMN}' in dataset, but not found.")

    features = df[FEATURE_COLUMNS]
    target = df[TARGET_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        features,
        target,
        test_size=0.2,
        random_state=42,
        stratify=target,
    )

    numeric_features = [
        "cgpa",
        "tenth_percentage",
        "twelfth_percentage",
        "backlogs",
        "programming_score",
        "dsa_score",
        "communication_score",
        "aptitude_score",
        "projects_completed",
        "internships",
        "certifications",
        "technical_skills",
        "graduation_year",
        "work_experience",
    ]
    categorical_features = ["degree"]

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "numeric",
                Pipeline([("imputer", SimpleImputer(strategy="median"))]),
                numeric_features,
            ),
            (
                "categorical",
                Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]),
                categorical_features,
            ),
        ]
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(random_state=42, n_estimators=250, min_samples_leaf=2, class_weight="balanced"),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42),
    }

    evaluations = []
    for name, model in models.items():
        pipeline = Pipeline([("preprocessor", preprocessor), ("model", model)])
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1]
        metrics = compute_metrics(y_test, y_pred, y_proba)
        evaluations.append({"model_name": name, "metrics": metrics, "pipeline": pipeline})

    best_entry = max(evaluations, key=lambda item: item["metrics"]["f1_score"])
    best_pipeline = best_entry["pipeline"]
    best_metrics = best_entry["metrics"]

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(
        {
            "model": best_pipeline,
            "feature_order": FEATURE_COLUMNS,
            "best_model_name": best_entry["model_name"],
        },
        MODEL_PATH,
    )

    final_metrics = {
        "model_name": best_entry["model_name"],
        **best_metrics,
    }
    with METRICS_PATH.open("w", encoding="utf-8") as fh:
        json.dump(final_metrics, fh, indent=2)

    print("Model training complete.")
    print(json.dumps(final_metrics, indent=2))
